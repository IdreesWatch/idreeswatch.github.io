#ifndef CARTRIDGE_H
#define CARTRIDGE_H

#include <SD.h>
#include <SPI.h>
#include <vector>

#include "../flash_mmap.h"
#include "../profiler.h"
#include "mapper.h"
#include "mappers/mapper000.h"
#include "mappers/mapper001.h"
#include "mappers/mapper002.h"
#include "mappers/mapper003.h"
#include "mappers/mapper004.h"
#include "mappers/mapper069.h"
#include "mirror_mode.h"
#include "ppu2C02.h"
#include "rom_backends.h"

class Bus;
class Cartridge
{
public:
    Cartridge(const char* filename, ROMBackend backend = ROMBackend::LRU);
    ~Cartridge();

    void ppuScanline();
    void cpuCycle(int cycles);
    bool needsCpuClock() const { return mapper_ID == 69; }
    void reset();

    void mapPages(Bus* bus);
    void mapPPUPages(Ppu2C02* ppu);

    void loadPRGBank(uint8_t* bank, uint16_t size, uint32_t offset);
    void loadCHRBank(uint8_t* bank, uint16_t size, uint32_t offset);
    void setMirrorMode(MIRROR mirror);
    MIRROR getMirrorMode();
    void connectBus(Bus* n)
    {
        bus = n;
    }
    void IRQ();

    void dumpState(File& state);
    void loadState(File& state);
    bool isValid();

    void seek(uint32_t offset);
    void read(uint8_t* buf, size_t size);

    MIRROR hardware_mirror;
    MIRROR mirror = MIRROR::HORIZONTAL;
    uint32_t CRC32 = ~0U;
    MappedROM mROM;
    Mapper mapper;

private:
    Bus* bus = nullptr;
    bool is_valid = true;
    uint32_t prg_base;
    uint32_t chr_base;

    File rom;
    uint8_t mapper_ID = 0;
    void createMapper(uint8_t number_PRG_banks, uint8_t number_CHR_banks, ROMBackend backend);
    uint32_t crc32(const void* buf, size_t size, uint32_t seed = ~0U);
};

#endif
