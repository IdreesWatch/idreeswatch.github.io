# Keep the pinned CPU's instruction batching, but clock devices for every
# consumed NES cycle. The old per-iteration APU call skipped most of them.
file(READ "${ANEMOIA_CPU_SOURCE}" CPU_TEXT)
string(REPLACE
    "        if (idreeswatch_apu_phase == 0) apu.clock();\n        idreeswatch_apu_phase ^= 1;\n"
    "" CPU_TEXT "${CPU_TEXT}")
if(NOT CPU_TEXT MATCHES "auto clock_devices")
    string(REPLACE
        "    uint8_t additional_cycle1, additional_cycle2;"
        [=[    uint8_t additional_cycle1, additional_cycle2;
    auto clock_devices = [this](int count) {
        const uint32_t apu_ticks = (count + (idreeswatch_apu_phase == 0 ? 1 : 0)) / 2;
        idreeswatch_apu_phase ^= count & 1;
        apu.clock(apu_ticks);
        bus.cart->cpuCycle(count);
    };]=] CPU_TEXT "${CPU_TEXT}")
    string(REPLACE
        [=[            cycles--;
            bus.cart->cpuCycle(1);
            continue;]=]
        [=[            const int spent = cycles < remaining_cycles ? cycles : remaining_cycles;
            cycles -= spent;
            remaining_cycles -= spent - 1;
            clock_devices(spent);
            continue;]=] CPU_TEXT "${CPU_TEXT}")
    string(REPLACE
        [=[        if (remaining_cycles >= cycles)
        {
            remaining_cycles -= (cycles - 1);
            bus.cart->cpuCycle(cycles);
            cycles = 0;
            continue;
        }
        else
        {
            cycles -= remaining_cycles;
            bus.cart->cpuCycle(remaining_cycles);
            return;
        }]=]
        [=[        const int spent = cycles < remaining_cycles ? cycles : remaining_cycles;
        cycles -= spent;
        remaining_cycles -= spent - 1;
        clock_devices(spent);]=] CPU_TEXT "${CPU_TEXT}")
endif()
if(NOT CPU_TEXT MATCHES "clock_devices\\(spent\\)" OR CPU_TEXT MATCHES "bus.cart->cpuCycle\\(remaining_cycles\\)")
    message(FATAL_ERROR "Pinned CPU device-clock patch no longer matches")
endif()
# NTSC has 240 visible, one post-render, 20 VBlank and one pre-render
# scanline. Upstream used 2501 CPU cycles (22 lines) for VBlank, which
# overran both the advertised 60.1 Hz frame and the audio sample budget.
string(REPLACE "    clock(2501);" "    clock(2273);" CPU_TEXT "${CPU_TEXT}")
file(WRITE "${ANEMOIA_CPU_SOURCE}" "${CPU_TEXT}")
set(APU_HEADER "${ANEMOIA_SOURCE_DIR}/src/core/apu2A03.h")
set(APU_SOURCE "${ANEMOIA_SOURCE_DIR}/src/core/apu2A03.cpp")
file(READ "${APU_HEADER}" APU_TEXT)
if(NOT APU_TEXT MATCHES "void clock\\(uint32_t ticks\\);")
    string(REPLACE "    void clock();" "    void clock();\n    void clock(uint32_t ticks);" APU_TEXT "${APU_TEXT}")
    file(WRITE "${APU_HEADER}" "${APU_TEXT}")
endif()
file(READ "${APU_SOURCE}" APU_TEXT)
if(NOT APU_TEXT MATCHES "idreeswatch_apu_batch.inc")
    file(APPEND "${APU_SOURCE}" "\n#include \"idreeswatch_apu_batch.inc\"\n")
endif()

# Instructions usually advance only one or two APU ticks. Cache the distance
# to the next actual channel/sample/sequencer event instead of recomputing
# every channel deadline after every 6502 instruction. Register writes and
# single-cycle reference clocks invalidate it; no emulated time is deferred.
file(READ "${APU_HEADER}" APU_TEXT)
if(NOT APU_TEXT MATCHES "invalidateClockCache")
    string(REPLACE "    void clock(uint32_t ticks);"
        "    void clock(uint32_t ticks);\n    void invalidateClockCache() { idreeswatch_safe_ticks = 0; }" APU_TEXT "${APU_TEXT}")
    string(REPLACE "private:\n    Bus* bus"
        "private:\n    uint32_t idreeswatch_safe_ticks = 0;\n    Bus* bus" APU_TEXT "${APU_TEXT}")
    if(NOT APU_TEXT MATCHES "uint32_t idreeswatch_safe_ticks")
        message(FATAL_ERROR "Pinned APU cache field insertion failed")
    endif()
    file(WRITE "${APU_HEADER}" "${APU_TEXT}")
endif()
file(READ "${APU_SOURCE}" APU_TEXT)
foreach(SIGNATURE IN ITEMS "void Apu2A03::clock()" "void Apu2A03::cpuWrite(uint16_t addr, uint8_t data)" "void Apu2A03::reset()")
    string(REPLACE "${SIGNATURE}\n{\n" "${SIGNATURE}\n{\n    invalidateClockCache();\n" APU_TEXT "${APU_TEXT}")
endforeach()
# Collapse duplicates on reconfigure while retaining a deterministic patch.
string(REPLACE "    invalidateClockCache();\n    invalidateClockCache();\n"
    "    invalidateClockCache();\n" APU_TEXT "${APU_TEXT}")
file(WRITE "${APU_SOURCE}" "${APU_TEXT}")
