# Inline the already-tested page-table fast path into CPU instruction fetches.
# RAM/ROM reads avoid one cross-object function call per access; I/O still uses
# precisely the original handlers, preserving register/controller semantics.
set(BUS_HEADER "${ANEMOIA_SOURCE_DIR}/src/core/bus.h")
set(BUS_SOURCE "${ANEMOIA_SOURCE_DIR}/src/core/bus.cpp")
file(READ "${BUS_HEADER}" BUS_H)
file(READ "${BUS_SOURCE}" BUS_CPP)
foreach(KIND IN ITEMS Write Read)
    if(KIND STREQUAL "Write")
        set(DECL "    void cpuWrite(uint16_t addr, uint8_t data);")
        set(BEGIN "IRAM_ATTR void Bus::cpuWrite(uint16_t addr, uint8_t data)")
        set(NEXT "IRAM_ATTR uint8_t Bus::cpuRead")
        set(INLINE "    inline void cpuWrite(uint16_t addr, uint8_t data)")
    else()
        set(DECL "    uint8_t cpuRead(uint16_t addr);")
        set(BEGIN "IRAM_ATTR uint8_t Bus::cpuRead(uint16_t addr)")
        set(NEXT "void Bus::setController")
        set(INLINE "    inline uint8_t cpuRead(uint16_t addr)")
    endif()
    string(FIND "${BUS_H}" "${DECL}" DECL_AT)
    if(NOT DECL_AT LESS 0)
        string(FIND "${BUS_CPP}" "${BEGIN}" START_AT)
        string(FIND "${BUS_CPP}" "${NEXT}" END_AT)
        if(START_AT LESS 0 OR END_AT LESS START_AT)
            message(FATAL_ERROR "Pinned Bus fast path changed")
        endif()
        math(EXPR COUNT "${END_AT} - ${START_AT}")
        string(SUBSTRING "${BUS_CPP}" ${START_AT} ${COUNT} BODY)
        string(REPLACE "${BEGIN}" "${INLINE}" HEADER_BODY "${BODY}")
        string(REPLACE "${DECL}" "${HEADER_BODY}" BUS_H "${BUS_H}")
        string(REPLACE "${BODY}" "" BUS_CPP "${BUS_CPP}")
    endif()
endforeach()
file(WRITE "${BUS_HEADER}" "${BUS_H}")
file(WRITE "${BUS_SOURCE}" "${BUS_CPP}")

# Only FME-7 (mapper 69) has a CPU-cycle callback among supported mappers.
# Cache that cartridge property at reset, avoiding empty per-instruction calls
# for Mario/NROM and other supported cartridges. APU timing stays independent.
set(CART_HEADER "${ANEMOIA_SOURCE_DIR}/src/core/cartridge.h")
file(READ "${CART_HEADER}" TEXT)
if(NOT TEXT MATCHES "needsCpuClock")
    string(REPLACE "    void cpuCycle(int cycles);"
        "    void cpuCycle(int cycles);\n    bool needsCpuClock() const { return mapper_ID == 69; }" TEXT "${TEXT}")
    file(WRITE "${CART_HEADER}" "${TEXT}")
endif()
file(READ "${ANEMOIA_CPU_HEADER}" TEXT)
if(NOT TEXT MATCHES "idreeswatch_clock_mapper")
    string(REPLACE "    uint8_t idreeswatch_apu_phase = 0;"
        "    uint8_t idreeswatch_apu_phase = 0;\n    bool idreeswatch_clock_mapper = false;" TEXT "${TEXT}")
    file(WRITE "${ANEMOIA_CPU_HEADER}" "${TEXT}")
endif()
file(READ "${ANEMOIA_CPU_SOURCE}" TEXT)
string(REPLACE "        bus.cart->cpuCycle(count);"
    "        if (idreeswatch_clock_mapper) bus.cart->cpuCycle(count);" TEXT "${TEXT}")
if(NOT TEXT MATCHES "idreeswatch_clock_mapper = bus.cart")
    string(REPLACE "    idreeswatch_apu_phase = 0;"
        "    idreeswatch_apu_phase = 0;\n    idreeswatch_clock_mapper = bus.cart->needsCpuClock();" TEXT "${TEXT}")
endif()
file(WRITE "${ANEMOIA_CPU_SOURCE}" "${TEXT}")
file(READ "${ANEMOIA_PPU_SOURCE}" TEXT)
string(REPLACE "v.reg = (scanline == 0) ? t.reg : v.reg = (v.reg & ~0x041F) | (t.reg & 0x041F);"
    "v.reg = (scanline == 0) ? t.reg : ((v.reg & ~0x041F) | (t.reg & 0x041F));" TEXT "${TEXT}")
file(WRITE "${ANEMOIA_PPU_SOURCE}" "${TEXT}")
