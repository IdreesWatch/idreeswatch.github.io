cmake_minimum_required(VERSION 3.16)

include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(idreeswatch_nes)

execute_process(
    COMMAND ${CMAKE_C_COMPILER} -print-libgcc-file-name
    OUTPUT_VARIABLE IDREESWATCH_LIBGCC
    OUTPUT_STRIP_TRAILING_WHITESPACE
    COMMAND_ERROR_IS_FATAL ANY
)
set(ELF_LIBS
    "esp-idf/nes_core/libnes_core.a"
    "${IDREESWATCH_LIBGCC}"
)
include(elf_loader)
project_so(idreeswatch_nes)
# project_so passes ELF_LIBS to the linker but does not track their timestamps.
# Otherwise editing the emulator rebuilds its archive yet ships a stale module.
add_custom_command(OUTPUT "${CMAKE_BINARY_DIR}/idreeswatch_nes.so" APPEND
    DEPENDS "${CMAKE_BINARY_DIR}/esp-idf/nes_core/libnes_core.a")
