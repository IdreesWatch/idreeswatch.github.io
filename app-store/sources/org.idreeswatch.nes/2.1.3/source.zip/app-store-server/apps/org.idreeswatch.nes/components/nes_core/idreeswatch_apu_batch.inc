/* Advance only intervals with no timer, mixer or frame-sequencer event.
 * At an event boundary the original single-clock implementation runs intact.
 * This preserves PCM and DMC stalls while avoiding per-cycle channel dispatch. */
void Apu2A03::clock(uint32_t ticks)
{
    while (ticks) {
        if (idreeswatch_safe_ticks == 0) {
        uint32_t distance_to_event = UINT32_MAX;
        auto limit = [&distance_to_event](uint32_t distance) {
            if (distance < distance_to_event) distance_to_event = distance;
        };
        if (pulse1_enable) limit(pulse1.seq.timer);
        if (pulse2_enable) limit(pulse2.seq.timer);
        if (noise_enable) limit(noise.timer);
        if (DMC_enable) limit(DMC.timer);
        if (triangle_enable) {
            const uint32_t distance = triangle.seq.timer ? triangle.seq.timer : 65536U;
            limit((distance - 1U) / 2U);
        }
        const uint32_t sequence_events[] = {3728, 7456, 11185, 14914, 18640};
        for (uint32_t event : sequence_events) {
            if (event >= clock_counter) { limit(event - clock_counter); break; }
        }
        limit((894886U - pulse_hz) / SAMPLE_RATE);
        idreeswatch_safe_ticks = distance_to_event;
        }
        uint32_t skip = ticks < idreeswatch_safe_ticks ? ticks : idreeswatch_safe_ticks;
        if (skip) {
            if (pulse1_enable) pulse1.seq.timer -= skip;
            if (pulse2_enable) pulse2.seq.timer -= skip;
            if (noise_enable) noise.timer -= skip;
            if (DMC_enable) DMC.timer -= skip;
            if (triangle_enable) triangle.seq.timer -= 2U * skip;
            clock_counter += skip;
            pulse_hz += SAMPLE_RATE * skip;
            ticks -= skip;
            idreeswatch_safe_ticks -= skip;
        } else {
            clock();
            --ticks;
        }
    }
}
